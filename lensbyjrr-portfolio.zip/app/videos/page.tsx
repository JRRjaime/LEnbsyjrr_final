import VideosPageClient from "./VideosPageClient"

export const metadata = {
  title: "Videos - LensByJRR",
  description: "Agrega y organiza tus videos fácilmente",
}

export default function VideosPage() {
  return <VideosPageClient />
}
