import FotografiaPageClient from "./FotografiaPageClient"

export const metadata = {
  title: "Fotografías - LensByJRR",
  description: "Galería de fotografías minimalista",
}

export default function FotografiaPage() {
  return <FotografiaPageClient />
}
